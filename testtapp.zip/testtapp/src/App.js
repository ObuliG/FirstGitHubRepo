import React from 'react';
// import logo from './logo.svg';
//import './App.css';
import { library } from '@fortawesome/fontawesome-svg-core';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome'
import { faThLarge, faSearch,faEye,faUser,faChevronLeft,faSyncAlt} from '@fortawesome/free-solid-svg-icons'

import Header from './components/shared/Header/Header';
import Footer from './components/shared/Footer/Footer';
import Menu from  './components/shared/Menu/Menu';

library.add(faThLarge,faSearch,faEye,faUser,faChevronLeft,faSyncAlt);

function App() {
  return (
    <div>
        <Header />
        <Menu />
        <Footer />
    </div>
  );
}

export default App;
