import React, { Component } from 'react';

class Admin extends Component {
    render() {
        return (
            <form>
                <div className="form-group row">
                    <label for="Sel_SelectFunction" className="font-weight-bold col-form-label col-sm-2">Select Function:</label>
                    <select className="form-control form-control-sm col-sm-2" id="Sel_SelectFunction">
                        <option>User Maintenance</option>
                        <option>HPS Location Maintenance</option>
                        <option>Station/Loc Maintenance</option>
                        <option>Correct Work Order</option>
                    </select>
                </div>
            </form>
        );
    }
}

export default Admin;