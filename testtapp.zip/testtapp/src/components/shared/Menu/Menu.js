import React, { PureComponent } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import './Menu.css';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import ScanJob from '../../ScanJob/ScanJob';
import ViewJob from '../../ViewJob/ViewJob';
import Admin from '../../Admin/Admin';




class menu extends PureComponent {

    render() {
        const posts = [
            { id: '1', title: 'Scan A Job', component: 'ScanJob', path: '/scanjob', icon: 'search' },
            { id: '2', title: 'View Jobs', component: 'ViewJob', path: '/viewjob', icon: 'eye' },
            { id: '3', title: 'Admin', component: 'Admin', path: '/', icon: 'user' }
        ];

        const ListItems = posts.map((post) =>         
            <li className="border-bottom" key={post.id}><Link to={post.path}> <FontAwesomeIcon icon={post.icon} /><span className="nav-label">{post.title}</span> </Link></li>
        );
          

        return (
            <Router>
                <div className="container-fluid">
                    <div className="row">
                        <div className="sidebar col-sm-2 border-right p-0">
                            <ul className="list-sidebar bg-defoult">
                                {/* <li className="border-bottom" > <Link to="/scanjob"> <FontAwesomeIcon icon="search" /> <span className="nav-label">Scan A Job</span> </Link></li>
                                <li className="border-bottom" > <Link to="/viewjob"> <FontAwesomeIcon icon="eye" /> <span className="nav-label">View Jobs</span></Link> </li>
                                <li className="border-bottom" > <Link to="/"> <FontAwesomeIcon icon="user" /> <span className="nav-label">Admin</span></Link></li> */}
                                {ListItems}
                            </ul>
                        </div>
                        <div className="col-sm-10 pt-2">
                            <Route exact path="/" component={Admin} />
                            <Route path="/scanjob" component={ScanJob} />
                            <Route path="/viewjob" component={ViewJob} />
                        </div>
                    </div>
                </div>
            </Router>
        );
    }
}

export default menu;