import React, { PureComponent } from 'react';
import Footerimage from '../../../images/footerimage.png';
import './Footer.css'

class Footer extends PureComponent {
    render() {
        return (
            <footer className="footer border-top">
                <div className="container">
                    <div className="row">
                        <div className="footer-copyright col-md-4 text-left">© Parker Hannifin Corp 2019</div>
                        <div className="col-md-8 text-right text"><img src={Footerimage} alt="logo" /></div>
                    </div>
                </div>
            </footer>
        );
    }
}

export default Footer;