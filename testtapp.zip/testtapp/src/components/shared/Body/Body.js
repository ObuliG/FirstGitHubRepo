import React, { Component } from 'react';
import {BrowserRouter as Router,Route,Link} from 'react-router-dom';

class Body extends Component {
    render() {
        return (
            <h1>hi,i am loaded from ScanJob</h1>
        );
    }
}

export default Body;