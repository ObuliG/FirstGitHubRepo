import React, { PureComponent } from 'react';
import logo from '../../../images/logo.jpg';
import './Header.css';

class Header extends PureComponent {
    render() {
        return (
            
                <header className="main-header">
                    <div className="container-fluid py-3">
                        <a className="App-logo-container" href="#">
                            <img src={logo} className="App-logo" alt="logo" />
                        </a>
                        <div className="App-name-container"><span className="App-name">HPS</span></div>
                    </div>
                </header>
            
        );
    }
}

export default Header;