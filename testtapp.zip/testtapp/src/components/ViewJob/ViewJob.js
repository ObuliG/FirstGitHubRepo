import React, { Component } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { MDBDataTable } from 'mdbreact';
import './ViewJob.css';

class ViewJob extends Component {
    render() {
        const data = {
            columns: [
                {
                    label: 'Work Order',
                    field: 'WorkOrder',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Part Number',
                    field: 'PartNumber',
                    sort: 'asc',
                    width: 270
                },
                {
                    label: 'Plant',
                    field: 'Plant',
                    sort: 'asc',
                    width: 200
                },
                {
                    label: 'Station/Location',
                    field: 'StationLocation',
                    sort: 'asc',
                    width: 100
                },
                {
                    label: 'Operator',
                    field: 'Operator',
                    sort: 'asc',
                    width: 150
                },
                {
                    label: 'Timestamp',
                    field: 'Timestamp',
                    sort: 'asc',
                    width: 100
                }
            ],
            rows: [
                {
                    WorkOrder: '1',
                    PartNumber: '12345',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '2',
                    PartNumber: '65478',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '3',
                    PartNumber: '25873',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '4',
                    PartNumber: '98547',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '5',
                    PartNumber: '3565',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '6',
                    PartNumber: '12453',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '7',
                    PartNumber: '68942',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '8',
                    PartNumber: '12457',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '9',
                    PartNumber: '366858',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '10',
                    PartNumber: '25874',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '11',
                    PartNumber: '36987',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                {
                    WorkOrder: '12',
                    PartNumber: '8546',
                    Plant: 'Cleveland',
                    StationLocation: 'USA',
                    Operator: 'Parker',
                    Timestamp: '2011/04/25'
                },
                
            ]
        };
        return (
            <div>
                <form>
                    <div className="form-row align-items-center">
                        <div className="col-auto">
                            <label for="Sel_Location" className="font-weight-bold col-form-label ">Location:</label>
                        </div>
                        <div className="col-auto">
                            <select className="form-control form-control-sm" id="Sel_Location">
                                <option>--Select--</option>
                            </select>
                        </div>
                        |
                    <div className="col-auto">
                            <label for="txt_StationLocation" className="font-weight-bold col-form-label">Create Date Range:</label>
                        </div>
                        <div className="col-auto txt-width">
                            <input type="text" id="txt_StationLocation" className="form-control form-control-sm"></input>
                        </div><div class="col-auto">
                            <span>&</span>
                        </div>
                        <div className="col-auto txt-width">
                            <input type="text" id="txt_Quantity" className="form-control form-control-sm"></input>
                        </div>
                        <div className="col-auto">
                            <div><FontAwesomeIcon icon="sync-alt" /></div>
                        </div>
                        |
                    <div className="col-auto">
                            <label for="txt_Operator" className="font-weight-bold col-form-label">Search By Work Order:</label>
                        </div>
                        <div className="col-auto">
                            <input type="text" id="txt_Operator" className="form-control form-control-sm"></input>
                        </div>
                        <div className="col-auto">
                            <button type="button" className="btn btn-secondary btn-sm">Go</button>
                        </div>
                        <div className="col-auto">
                            <button type="button" className="btn btn-secondary btn-sm">Clear</button>
                        </div>
                    </div>
                </form>
                <div className="mt-4">
                    {/* <table class="table table-sm table-striped table-bordered table-hover">
                        <thead class="thead-dark">
                            <tr>
                                <th>Work Order</th>
                                <th>Part Number</th>
                                <th>Plant</th>
                                <th>Station/Location</th>
                                <th>Operator</th>
                                <th>Timestamp</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th>1</th>
                                <td>123456</td>
                                <td>Cleveland</td>
                                <td>USA</td>
                                <td>Parker</td>
                                <td>9/25/2019</td>
                            </tr>
                            <tr>
                                <th>2</th>
                                <td>123456</td>
                                <td>NewYork</td>
                                <td>USA</td>
                                <td>Parker</td>
                                <td>9/25/2019</td>
                            </tr>
                            <tr>
                                <th>3</th>
                                <td>123456</td>
                                <td>chennai</td>
                                <td>India</td>
                                <td>Parker</td>
                                <td>9/25/2019</td>
                            </tr>
                        </tbody>
                    </table> */}
                    <MDBDataTable
                        striped
                        bordered
                        hover
                        data={data}
                    />
                </div>
            </div>
        );
    }
}

export default ViewJob;