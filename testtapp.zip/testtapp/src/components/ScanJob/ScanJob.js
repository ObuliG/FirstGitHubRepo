import React, { Component } from 'react';
import './ScanJob.css';

class ScanJob extends Component {
    render() {
        return (
            <form>
                <div className="form-group row">
                    <label for="txt_WorkOrderNumber" className="font-weight-bold col-form-label col-sm-2">Work Order Number:</label>
                    <div className="col-sm-3">
                        <input type="text" id="txt_WorkOrderNumber" className="form-control form-control-sm" placeholder="Enter Work Order"></input>
                    </div>
                </div>
                <div className="form-group row">
                    <label for="txt_StationLocation" className="font-weight-bold col-form-label col-sm-2">Station/Location:</label>
                    <div className="col-sm-3">
                        <input type="text" id="txt_StationLocation" className="form-control form-control-sm" placeholder="Enter Station/Location"></input>
                    </div>
                </div>
                <div className="form-group row">
                    <label for="txt_Quantity" className="font-weight-bold col-form-label col-sm-2">Quantity:</label>
                    <div className="col-sm-3">
                        <input type="text" id="txt_Quantity" className="form-control form-control-sm" placeholder="Enter Quantity"></input>
                    </div>
                </div>
                <div className="form-group row">
                    <label for="txt_Operator" className="font-weight-bold col-form-label col-sm-2">Operator:</label>
                    <div className="col-sm-3">
                        <input type="text" id="txt_Operator" className="form-control form-control-sm" placeholder="Enter Operator"></input>
                    </div>
                </div>
                <div className="form-group row">
                    <div className="col-sm-5 text-right p-0">
                        <button type="button" className="btn btn-secondary btn-sm">Go</button>
                    </div>
                </div>
            </form>
        );
    }
}

export default ScanJob;