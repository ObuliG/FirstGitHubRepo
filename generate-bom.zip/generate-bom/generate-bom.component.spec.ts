import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateBOMComponent } from './generate-bom.component';

describe('GenerateBOMComponent', () => {
  let component: GenerateBOMComponent;
  let fixture: ComponentFixture<GenerateBOMComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateBOMComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateBOMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
