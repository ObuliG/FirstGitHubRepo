import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { Observable, throwError } from 'rxjs';
import { map, catchError } from 'rxjs/operators';

//User created components
import { Attributes } from "./attributes";

@Injectable()
export class BomService {
  url: string = 'http://corpappsdev/corpapps/eManufacturingAPI';
  constructor(private _httpClient: HttpClient) { }

  getAttributes(): Observable<Attributes[]> {
    const httpOptions = {
      headers: new HttpHeaders({
        'Content-Type': 'application/json',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET',
        'Access-Control-Allow-Headers': 'Content-Type',
      })
    };
    const data = this._httpClient.get<Attributes[]>(this.url + '/api/eManufacturing/BuildAttributeValues/A63918/OSP-P32', httpOptions)
      .pipe(catchError(this.handleError));
    return data;
  }

  handleError(error: any) {
    let errorMessage = '';
    // client-side error
    if (error.error instanceof ErrorEvent) {
      errorMessage = `Error: ${error.error.message}`;
    }
    // server-side error
    else {
      errorMessage = `Error Code: ${error.status} \n Message: ${error.message}`;
    }
    return throwError(errorMessage);
  }
}
