import React from 'react';
import { MDBDataTable } from 'mdbreact';

function ViewJobList({ workOrderList, isPageLoading }) {
    if (isPageLoading) {
        return <h1>Loading....</h1>
    }

    const data = {
        columns: [
            {
                label: 'Work Order',
                field: 'WorkOrderNumber',
                sort: 'asc',
                width: 150
            },
            {
                label: 'Part Number',
                field: 'PartNumber',
                sort: 'asc',
                width: 270
            },
            {
                label: 'Plant',
                field: 'Plant',
                sort: 'asc',
                width: 200
            },
            {
                label: 'Station/Location',
                field: 'StationLocation',
                sort: 'asc',
                width: 100
            },
            {
                label: 'Operator',
                field: 'Operator',
                sort: 'asc',
                width: 150
            },
            {
                label: 'Timestamp',
                field: 'Timestamp',
                sort: 'asc',
                width: 100
            }
        ],
        rows: workOrderList
        
    };
    return (
        <div>
            
            {
                <MDBDataTable
                    striped
                    bordered
                    hover
                    data={data}
                />
            }
        </div>
    );
};

export default ViewJobList
