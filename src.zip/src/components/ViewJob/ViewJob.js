import React, { useState, useEffect } from 'react';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import './ViewJob.css';
import axios from 'axios';
import ViewJobList from "./ViewJobList";
import HttpGet from '../CustomHooks/HttpGet';


function ViewJob() {
    const [loading, setLoading] = useState(false);
    const [posts, setPosts] = useState([]);

    const [location, setLocation] = useState("");
    const [fromDate, setFromDate] = useState("2019-09-10 12:39:56.627");
    const [toDate, setToDate] = useState("2019-09-11 17:18:02.440");
    const [workOrderNumber, setWorkOrderNumber] = useState("");


    const data = HttpGet({ url: "http://localhost:64726/api/WorkOrder/GetOrder", dependency: [] });
    console.log(data);
    const loadGrid = () => {

        // axios({
        //     method: "get",
        //     url: "http://localhost:64726/api/WorkOrder/GetOrder"
        // }).then(
        //     response => {
        //         setPosts(response.data);
        //         setLoading(false);
        //     }).catch(error => {
        //         console.log(error);
        //     });
    }

    const onLocationDropdownChange = (e) => {
        setLocation(e.target.value);

    }
    const onWorkOrderInputChange = (e) => {
        setWorkOrderNumber(e.target.value);
    };
    const onButtonGoClick = (e) => {
        setLoading(true);
        axios({
            method: "get",
            url: "http://localhost:64726/api/WorkOrder/GetWorkOrdersByWorkOrderNumber",
            params: { "workOrderNumber": workOrderNumber }
        }).then(
            response => {
                setPosts(response.data);
                setLoading(false);
            }).catch(error => {
                console.log(error);
            });
    };

    const onClearButtonClick = (e) => {
        if (workOrderNumber !== "") {
            setWorkOrderNumber("");
            loadGrid();
        }
    };

    useEffect(() => {
        const fetchPost = async () => {
            loadGrid();
        }
        fetchPost();
    }, []);

    useEffect(() => {
        if (location == "") return;
        if (location == "--Select--") {
            loadGrid();
        }
        else {
            setLoading(true);
            axios({
                method: "get",
                url: "http://localhost:64726/api/WorkOrder/GetWorkOrdersByLocation",
                params: { "location": location }
            }).then(
                response => {
                    setPosts(response.data);
                    setLoading(false);
                }).catch(error => {
                    console.log(error);
                });
        }
    }, [location]);

    return (
        <div>
            <form>
                <div className="form-row align-items-center">
                    <div className="col-auto">
                        <label htmlFor="Sel_Location" className="font-weight-bold col-form-label" >Location:</label>
                    </div>
                    <div className="col-auto">
                        <select className="form-control form-control-sm" id="Sel_Location" onChange={onLocationDropdownChange} >
                            <option>--Select--</option>
                            <option>STATION</option>
                            <option>Test station</option>
                        </select>
                    </div>
                    |
                     <div className="col-auto">
                        <label htmlFor="txt_StationLocation" className="font-weight-bold col-form-label">Create Date Range:</label>
                    </div>
                    <div className="col-auto txt-width">
                        <input type="text" id="txt_StationLocation" className="form-control form-control-sm"></input>
                    </div>
                    <div className="col-auto">
                        <span>&</span>
                    </div>
                    <div className="col-auto txt-width">
                        <input type="text" id="txt_Quantity" className="form-control form-control-sm"></input>
                    </div>
                    <div className="col-auto">
                        <div><FontAwesomeIcon icon="sync-alt" /></div>
                    </div>
                    |
                     <div className="col-auto">
                        <label htmlFor="txt_Operator" className="font-weight-bold col-form-label">Search By Work Order:</label>
                    </div>
                    <div className="col-auto">
                        <input type="text" id="txt_Operator" className="form-control form-control-sm" value={workOrderNumber} onChange={onWorkOrderInputChange}></input>
                    </div>
                    <div className="col-auto">
                        <button type="button" className="btn btn-secondary btn-sm" onClick={onButtonGoClick}>Go</button>
                    </div>
                    <div className="col-auto">
                        <button type="button" className="btn btn-secondary btn-sm" onClick={onClearButtonClick}>Clear</button>
                    </div>
                </div>
            </form>
            <ViewJobList workOrderList={posts} isPageLoading={loading} />
        </div>
    )
}
export default ViewJob;

// class ViewJob extends Component {
//     render() {
//         const data = {
//             columns: [
//                 {
//                     label: 'Work Order',
//                     field: 'WorkOrder',
//                     sort: 'asc',
//                     width: 150
//                 },
//                 {
//                     label: 'Part Number',
//                     field: 'PartNumber',
//                     sort: 'asc',
//                     width: 270
//                 },
//                 {
//                     label: 'Plant',
//                     field: 'Plant',
//                     sort: 'asc',
//                     width: 200
//                 },
//                 {
//                     label: 'Station/Location',
//                     field: 'StationLocation',
//                     sort: 'asc',
//                     width: 100
//                 },
//                 {
//                     label: 'Operator',
//                     field: 'Operator',
//                     sort: 'asc',
//                     width: 150
//                 },
//                 {
//                     label: 'Timestamp',
//                     field: 'Timestamp',
//                     sort: 'asc',
//                     width: 100
//                 }
//             ],
//             rows: [
//                 {
//                     WorkOrder: '1',
//                     PartNumber: '12345',
//                     Plant: 'Cleveland',
//                     StationLocation: 'USA',
//                     Operator: 'Parker',
//                     Timestamp: '2011/04/25'
//                 },
//                 {
//                     WorkOrder: '2',
//                     PartNumber: '65478',
//                     Plant: 'Cleveland',
//                     StationLocation: 'USA',
//                     Operator: 'Parker',
//                     Timestamp: '2011/04/25'
//                 }
//                 
//             ]
//         };
//         return (
//             <div>
//                 <form>
//                     <div className="form-row align-items-center">
//                         <div className="col-auto">
//                             <label htmlFor="Sel_Location" className="font-weight-bold col-form-label ">Location:</label>
//                         </div>
//                         <div className="col-auto">
//                             <select className="form-control form-control-sm" id="Sel_Location">
//                                 <option>--Select--</option>
//                             </select>
//                         </div>
//                         |
//                     <div className="col-auto">
//                             <label htmlFor="txt_StationLocation" className="font-weight-bold col-form-label">Create Date Range:</label>
//                         </div>
//                         <div className="col-auto txt-width">
//                             <input type="text" id="txt_StationLocation" className="form-control form-control-sm"></input>
//                         </div>
//                         <div className="col-auto">
//                             <span>&</span>
//                         </div>
//                         <div className="col-auto txt-width">
//                             <input type="text" id="txt_Quantity" className="form-control form-control-sm"></input>
//                         </div>
//                         <div className="col-auto">
//                             <div><FontAwesomeIcon icon="sync-alt" /></div>
//                         </div>
//                         |
//                     <div className="col-auto">
//                             <label htmlFor="txt_Operator" className="font-weight-bold col-form-label">Search By Work Order:</label>
//                         </div>
//                         <div className="col-auto">
//                             <input type="text" id="txt_Operator" className="form-control form-control-sm"></input>
//                         </div>
//                         <div className="col-auto">
//                             <button type="button" className="btn btn-secondary btn-sm">Go</button>
//                         </div>
//                         <div className="col-auto">
//                             <button type="button" className="btn btn-secondary btn-sm">Clear</button>
//                         </div>
//                     </div>
//                 </form>
//                 <div className="mt-4">
//                     {/* <table class="table table-sm table-striped table-bordered table-hover">
//                         <thead class="thead-dark">
//                             <tr>
//                                 <th>Work Order</th>
//                                 <th>Part Number</th>
//                                 <th>Plant</th>
//                                 <th>Station/Location</th>
//                                 <th>Operator</th>
//                                 <th>Timestamp</th>
//                             </tr>
//                         </thead>
//                         <tbody>
//                             <tr>
//                                 <th>1</th>
//                                 <td>123456</td>
//                                 <td>Cleveland</td>
//                                 <td>USA</td>
//                                 <td>Parker</td>
//                                 <td>9/25/2019</td>
//                             </tr>
//                             <tr>
//                                 <th>2</th>
//                                 <td>123456</td>
//                                 <td>NewYork</td>
//                                 <td>USA</td>
//                                 <td>Parker</td>
//                                 <td>9/25/2019</td>
//                             </tr>
//                             <tr>
//                                 <th>3</th>
//                                 <td>123456</td>
//                                 <td>chennai</td>
//                                 <td>India</td>
//                                 <td>Parker</td>
//                                 <td>9/25/2019</td>
//                             </tr>
//                         </tbody>
//                     </table> */}
//                     <MDBDataTable
//                         striped
//                         bordered
//                         hover
//                         data={data}
//                     />
//                 </div>
//             </div>
//         );
//     }
// }

// export default ViewJob;