import React, { useEffect } from "react";
import axios from "axios";

let data;

function HttpGet({ url, dependency }) {

    console.log("Success");
    useEffect(() => {
        axios.get(url)
            .then(response => {
                data = response;
                console.log(response);
            })
            .catch(error => {
                console.log(error);
            })

    }, [dependency]);
    return (
        { data }
    )
}

export default HttpGet
