import React, { useReducer } from 'react';
import './ScanJob.css';
import axios from "axios";

const initialState = {
    workOrderNumber: "",
    stationLocation: "",
    quantity: 0,
    Operator: "",
    mfgLocation: "",
    timeStamp: null,
    plant: "",
    partNumber: ""
};


const reducer = (state, action) => {
    switch (action.type) {
        case "workOrderNumber":
            return { ...state, workOrderNumber: action.payload };
        case "stationLocation":
            return { ...state, stationLocation: action.payload }
        case "quantity":
            return { ...state, quantity: action.payload }
        case "Operator":
            return { ...state, Operator: action.payload }
        default:
            return state;
    }
}

function ScanJob() {
    const [state, dispatch] = useReducer(reducer, initialState);

    const onGoButtonClick = (e) => {
        e.preventDefault();
        axios({
            method: 'post',
            url: 'http://localhost:64726/api/WorkOrder/CreateWorkOrder',
            data: state
        }).then(response => {
            console.log(response);
        }).catch(error => {
            console.log(error);
        })
    }

    return (
        <form>
            <div className="form-group row">
                <label htmlFor="txt_WorkOrderNumber" className="font-weight-bold col-form-label col-sm-2">Work Order Number:</label>
                <div className="col-sm-3">
                    <input type="text" id="txt_WorkOrderNumber" value={state.workOrderNumber} onChange={
                        (e) => {
                            dispatch(
                                {
                                    type: "workOrderNumber",
                                    payload: e.target.value
                                }
                            )
                        }}
                        className="form-control form-control-sm" placeholder="Enter Work Order"></input>
                </div>
            </div>
            <div className="form-group row">
                <label htmlFor="txt_StationLocation" className="font-weight-bold col-form-label col-sm-2">Station/Location:</label>
                <div className="col-sm-3">
                    <input type="text" id="txt_StationLocation" value={state.stationLocation} onChange={(e) => { dispatch({ type: "stationLocation", payload: e.target.value }) }} className="form-control form-control-sm" placeholder="Enter Station/Location"></input>
                </div>
            </div>
            <div className="form-group row">
                <label htmlFor="txt_Quantity" className="font-weight-bold col-form-label col-sm-2">Quantity:</label>
                <div className="col-sm-3">
                    <input type="text" id="txt_Quantity" value={state.quantity} onChange={(e) => { dispatch({ type: "quantity", payload: e.target.value }) }} className="form-control form-control-sm" placeholder="Enter Quantity"></input>
                </div>
            </div>
            <div className="form-group row">
                <label htmlFor="txt_Operator" className="font-weight-bold col-form-label col-sm-2">Operator:</label>
                <div className="col-sm-3">
                    <input type="text" id="txt_Operator" value={state.Operator} onChange={(e) => { dispatch({ type: "Operator", payload: e.target.value }) }} className="form-control form-control-sm" placeholder="Enter Operator"></input>
                </div>
            </div>
            <div className="form-group row">
                <div className="col-sm-5 text-right p-0">
                    <button type="submit" className="btn btn-secondary btn-sm" onClick={onGoButtonClick} >Go</button>
                </div>
            </div>
        </form>
    );
}
export default ScanJob;