import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LayoutComponent } from './shared/layout/layout.component';
import { MenuComponent } from './menu/menu.component';

import { GeneratebomComponent } from "./components/bomcomponent/generatebom.component";

const routes: Routes = [{
  // path: '',
  // component: LoginComponent,
  // data: { title: 'Login' }
  path: '',
  component: GeneratebomComponent,
  data: { title: 'GenerateBom' }
},

{
  path: '',
  component: LayoutComponent,
  children: [
    { path: 'GenerateBom', component: GeneratebomComponent, pathMatch: 'full' },
    // { path: 'Home', component: HomeComponent, pathMatch: 'full' },
    // { path: 'Menu', component: MenuComponent },
    // { path: 'test/:id', component: AboutComponent }
  ]
},

  // {
  //   path: 'Home',
  //   component: HomeComponent,
  //   data: { title: 'Home' }
  // },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
