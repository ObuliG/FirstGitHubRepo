import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { HomeComponent } from './home/home.component';
import { LoginComponent } from './login/login.component';
import { LayoutComponent } from './shared/layout/layout.component';
import { MenuComponent } from './menu/menu.component';

const routes: Routes = [{
  path: '',
  component: LoginComponent,
  data: { title: 'Login' }
},

{ 
  path: '', 
  component: LayoutComponent,
  children: [
    { path: 'Home', component: HomeComponent, pathMatch: 'full'},
    { path: 'Menu', component: MenuComponent },
    // { path: 'test/:id', component: AboutComponent }
  ]
},

// {
//   path: 'Home',
//   component: HomeComponent,
//   data: { title: 'Home' }
// },

];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
