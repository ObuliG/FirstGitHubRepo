export class SelectedControlList {
    ControlNumber: string;
    ControlValue: string;
    ConditionValue: number;
}