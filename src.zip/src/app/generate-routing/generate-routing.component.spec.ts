import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GenerateRoutingComponent } from './generate-routing.component';

describe('GenerateRoutingComponent', () => {
  let component: GenerateRoutingComponent;
  let fixture: ComponentFixture<GenerateRoutingComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GenerateRoutingComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GenerateRoutingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
