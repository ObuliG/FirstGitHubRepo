import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generate-routing',
  templateUrl: './generate-routing.component.html',
  styleUrls: ['./generate-routing.component.css']
})
export class GenerateRoutingComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
