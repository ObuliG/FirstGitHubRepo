import { ControlList  } from "./control-list";
export class Attributes {
    CONTROL_NUM: number;
    CONTROL_LABEL: string;
    CONTROL_TYPE: number
    CONTROL_VAL_LIST:ControlList[]
}