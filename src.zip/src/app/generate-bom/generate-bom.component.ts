import { Component, OnInit } from '@angular/core';
import {FormArray,FormGroup,FormBuilder} from '@angular/forms';
//User created components
import { Attributes } from "./attributes";
import { BomService } from "./bom.service";
import { ControlType } from "src/app/common/common-enum.component";
import { SelectedControlList } from "src/app/common/selected-control-list";


@Component({
  selector: 'app-generate-bom',
  templateUrl: './generate-bom.component.html',
  styleUrls: ['./generate-bom.component.css'],
  providers: [BomService]
})
export class GenerateBOMComponent implements OnInit {

  //Initializing form group.
  GenerateBomForm = new FormGroup({});

  //Initializing enums
  controlType = ControlType;

  item = [];

  //Initializing selected control list
  public selectedControlList: Array<SelectedControlList> = [];

  constructor(private fb: FormBuilder, private _bomService: BomService) { }

  //Initializing attribute instance
  public attributeResult: Attributes[];

  getAttribute() {
    this._bomService.getAttributes().subscribe(
      response => {
        this.attributeResult = response;
        console.log(this.attributeResult);
      },
      error => {
        console.log(error);
      });
  }

  ngOnInit() {

    //Initially getting the control and values from the server.
    this.getAttribute();

    //Initialize form with from group
    this.GenerateBomForm = this.fb.group({ items: new FormArray([]) });
  }

  isItemAlreadyExist(currentItem: any): boolean {
    let isItemExist = this.selectedControlList.find(x => x.ControlNumber == currentItem[0]);
    return isItemExist == null ? false : true;
  }
  ///<summary>
  /// Push selected control values to array.
  ///</summary>
  onChangeName(currentElement: any) {

    let selectedcontrolListObject = new SelectedControlList();
    let values = currentElement.split(',');
    if (this.isItemAlreadyExist(values)) {

      selectedcontrolListObject.ControlNumber = values[0];
      selectedcontrolListObject.ConditionValue = values[1];
      let cond_value = values[2] + 1;
      selectedcontrolListObject.ControlValue = cond_value;
      this.selectedControlList.push(selectedcontrolListObject);
    }
    else {
      selectedcontrolListObject.ControlNumber = values[0];
      selectedcontrolListObject.ConditionValue = values[1];
      selectedcontrolListObject.ControlValue = values[2];
      this.selectedControlList.push(selectedcontrolListObject);
    }





    console.log(this.selectedControlList);
  }

  onSubmit() {

    console.log('object');
    console.log(this.GenerateBomForm);
    //    console.log(this.attributeResult);
  }


}
