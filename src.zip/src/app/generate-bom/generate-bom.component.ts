import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-generate-bom',
  templateUrl: './generate-bom.component.html',
  styleUrls: ['./generate-bom.component.css']
})
export class GenerateBOMComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
