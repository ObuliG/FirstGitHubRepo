export class ControlList {
    VALUE_NUM: number;
    SCREEN_VALUE: string;
    MODEL_VALUE: number;
}