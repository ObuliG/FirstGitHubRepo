export enum ControlType {
    textBoxControl = 0,
    dropdownControl = 2
}